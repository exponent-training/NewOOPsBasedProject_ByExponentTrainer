package com.exponent.cabserviceapplication.model;

public class Cab {

	private int cabid;

	private String cabno;
	
	private boolean availabilityOfCab;
	
	private String cabtype;
	
	private Driver driver;

	public int getCabid() {
		return cabid;
	}

	public void setCabid(int cabid) {
		this.cabid = cabid;
	}

	public String getCabno() {
		return cabno;
	}

	public void setCabno(String cabno) {
		this.cabno = cabno;
	}

	public boolean isAvailabilityOfCab() {
		return availabilityOfCab;
	}

	public void setAvailabilityOfCab(boolean availabilityOfCab) {
		this.availabilityOfCab = availabilityOfCab;
	}

	public String getCabtype() {
		return cabtype;
	}

	public void setCabtype(String cabtype) {
		this.cabtype = cabtype;
	}

	public Driver getDriver() {
		return driver;
	}

	public void setDriver(Driver driver) {
		this.driver = driver;
	}

	@Override
	public String toString() {
		return "Cab [cabid=" + cabid + ", cabno=" + cabno + ", availabilityOfCab=" + availabilityOfCab + ", cabtype="
				+ cabtype + ", driver=" + driver + "]";
	}
	
	
	

}
