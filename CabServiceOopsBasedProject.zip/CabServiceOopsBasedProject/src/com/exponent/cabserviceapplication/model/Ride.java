package com.exponent.cabserviceapplication.model;

public class Ride {

	private int rideid;

	private double distance;

	private String pickupLocation;

	private String dropLocation;

	private Cab cab;

	private Customer customer;

	public int getRideid() {
		return rideid;
	}

	public void setRideid(int rideid) {
		this.rideid = rideid;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}

	public String getPickupLocation() {
		return pickupLocation;
	}

	public void setPickupLocation(String pickupLocation) {
		this.pickupLocation = pickupLocation;
	}

	public String getDropLocation() {
		return dropLocation;
	}

	public void setDropLocation(String dropLocation) {
		this.dropLocation = dropLocation;
	}

	public Cab getCab() {
		return cab;
	}

	public void setCab(Cab cab) {
		this.cab = cab;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	@Override
	public String toString() {
		return "Ride [rideid=" + rideid + ", distance=" + distance + ", pickupLocation=" + pickupLocation
				+ ", dropLocation=" + dropLocation + ", cab=" + cab + ", customer=" + customer + "]";
	}

}
