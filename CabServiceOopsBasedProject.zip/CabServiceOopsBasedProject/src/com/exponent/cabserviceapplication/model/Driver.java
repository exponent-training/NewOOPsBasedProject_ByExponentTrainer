package com.exponent.cabserviceapplication.model;

import java.io.Serializable;

public class Driver implements Serializable{

	// All the components an account has

	private int driverid;

	private String drivername;

	private String licenseno;

	private String PanCard;

	private long drivermobileNo;

	private double rating;

	public int getDriverid() {
		return driverid;
	}

	public void setDriverid(int driverid) {
		this.driverid = driverid;
	}

	public String getDrivername() {
		return drivername;
	}

	public void setDrivername(String drivername) {
		this.drivername = drivername;
	}

	public String getLicenseno() {
		return licenseno;
	}

	public void setLicenseno(String licenseno) {
		this.licenseno = licenseno;
	}

	public String getPanCard() {
		return PanCard;
	}

	public void setPanCard(String panCard) {
		PanCard = panCard;
	}

	public long getDrivermobileNo() {
		return drivermobileNo;
	}

	public void setDrivermobileNo(long mobileNo) {
		this.drivermobileNo = mobileNo;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "Driver [driverid=" + driverid + ", drivername=" + drivername + ", licenseno=" + licenseno + ", PanCard="
				+ PanCard + ", drivermobileNo=" + drivermobileNo + ", rating=" + rating + "]";
	}


	
}
