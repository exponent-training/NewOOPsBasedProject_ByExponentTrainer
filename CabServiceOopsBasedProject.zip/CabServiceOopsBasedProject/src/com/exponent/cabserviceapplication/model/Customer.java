package com.exponent.cabserviceapplication.model;

public class Customer {
	
	private int customerid;
	
	private String customername;
	
	private long customermobileno;

	private String customeraddress;

	public int getCustomerid() {
		return customerid;
	}

	public void setCustomerid(int customerid) {
		this.customerid = customerid;
	}

	public String getCustomername() {
		return customername;
	}

	public void setCustomername(String customername) {
		this.customername = customername;
	}

	public long getCustomermobileno() {
		return customermobileno;
	}

	public void setCustomermobileno(long customermobileno) {
		this.customermobileno = customermobileno;
	}

	public String getCustomeraddress() {
		return customeraddress;
	}

	public void setCustomeraddress(String customeraddress) {
		this.customeraddress = customeraddress;
	}

	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", customername=" + customername + ", customermobileno="
				+ customermobileno + ", customeraddress=" + customeraddress + "]";
	}
	
	
}
