package com.exponent.cabserviceapplication.validationchecker;

import java.util.Scanner;

public class ValidateAccountDetails {

	public static long validateMobileNo() {
		Scanner s1 = new Scanner(System.in);
		System.out.println("enter mobile no.:");
		long mobileno = s1.nextLong();
		
		if (mobileno>6000000000l && mobileno<9999999999l) {
			System.out.println("valid mobile no.!!");
			return mobileno;
		} else {
			System.out.println("Invalid mobile no.!!, please re-enter it again.");
			return validateMobileNo();
		}
	}
}
