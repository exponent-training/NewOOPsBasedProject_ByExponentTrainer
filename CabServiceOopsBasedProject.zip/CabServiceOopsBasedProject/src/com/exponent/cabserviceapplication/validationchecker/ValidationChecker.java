package com.exponent.cabserviceapplication.validationchecker;

import java.util.Scanner;
import java.util.regex.Pattern;

public class ValidationChecker {

	public static long getValidAccountNo() {
		/*
		 * Scanner sc = new Scanner(System.in); System.out.println("Enter accNo:"); long
		 * accno = sc.nextLong();
		 */
		long generateAccNo =(long) (Math.random() * Math.pow(10, 12));
		//return generateAccNo;
		System.out.println("generateAccNo= "+generateAccNo);
		String strAccno = String.valueOf(generateAccNo);
		if (strAccno.length() == 12) {
			System.out.println("Valid account number..");
			return generateAccNo;
		} else {
			System.out.println("Invalid account number, please re-ent account No.:");
			return getValidAccountNo();
		}
	}

	public static String getValidAccountHolderName() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name:");
		String nameInput = sc.next();
		if (Pattern.matches("[A-Za-z]+", nameInput)) {
			System.out.println("Valid name..");
			return nameInput;
		} else {
			System.out.println("Invalid name, please re-enter it again..");
			return getValidAccountHolderName();
		}
	}

	public static long getValidMobileNo() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter mobileno");
		long mobileNoInput = sc.nextLong();

		String strMobileNo = String.valueOf(mobileNoInput);

		if (strMobileNo.length() == 10
				&& (strMobileNo.startsWith("7") || strMobileNo.startsWith("8") || strMobileNo.startsWith("9"))) {
			System.out.println("Valid mobile no.");
			return mobileNoInput;
		} else {
			System.out.println("Invalid mobileno, please re-enter it again..");
			return getValidMobileNo();
		}

	}

	// PASRT4567Y
	public static String getValidPancardNo() {
		System.out.println("enter panno:");
		Scanner sc = new Scanner(System.in);

		String pannoIn = sc.next();

		if (pannoIn.length() == 10 && Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}", pannoIn)) {
			System.out.println("Valid panno.");
			return pannoIn;
		} else {
			System.out.println("Invalid panno, please re-enter it again..");
			return getValidPancardNo();
		}

	}
	
	public static String getValidEmailId() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter mailid:");
		String emailIdIn= sc.next();
		if (Pattern.matches("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}", emailIdIn)) {
			System.out.println("Valid email id");
			return emailIdIn;
		} else {
			System.out.println("Invalid emailid, please re-enter it again..");
			return getValidEmailId();
		}
	}
	
	public static String getvalidAadharcardNo() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter aadharno:");
		String aadharnoIn= sc.nextLine();
		if (Pattern.matches("[2-9]{1}[0-9]{3}[ ]{1}[0-9]{4}[ ]{1}[0-9]{4}", aadharnoIn)) {
			System.out.println("Valid aadharno ");
			return aadharnoIn;
		} else {
			System.out.println("Invalid aadharno, please re-enter it again..");
			return getvalidAadharcardNo();
		}
	}

}












