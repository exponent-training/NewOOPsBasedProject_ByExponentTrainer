package com.exponent.cabserviceapplication.service;

public interface CabServiceInterface {

	public void addDriverDetails();

	//We can have multiple cars
	public void addCabDetails();

	public void addCustomerDetails();

	public void addRideDetails();

	public void displayDetails();

	public double calculateFare();
	
	public void startRide();

	public void endRide();
	

}
