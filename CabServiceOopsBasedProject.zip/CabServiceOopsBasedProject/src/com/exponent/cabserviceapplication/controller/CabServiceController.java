package com.exponent.cabserviceapplication.controller;

import java.util.Scanner;

import com.exponent.cabserviceapplication.service.CabServiceInterface;
import com.exponent.cabserviceapplication.serviceimpl.CabServiceImpl;

public class CabServiceController {

	// All the choices

	public static void main(String[] args) {

		System.out.println("*********WELCOME TO SBI BANK***********");
		Scanner sc = new Scanner(System.in);

		boolean flag = true;
		CabServiceInterface s = new CabServiceImpl();

		while (flag) {
			System.out.println();
			System.out.println("------------------------------------------");
			System.out.println("------------------------------------------");
			System.out.println("1: Add Driver Information              |");
			System.out.println("2: Add Cab Information                 |");
			System.out.println("3: Add Customer Information            |");
			System.out.println("4: Add Ride Information                |");
			System.out.println("5: Display Details                     |");
			System.out.println("6: Calculate Total fare                |");
			System.out.println("7: Start Ride                          |");
			System.out.println("8: End Ride                            |");
			System.out.println("9: EXIT                                |");
			System.out.println("------------------------------------------");
			System.out.println("------------------------------------------");
			System.out.println();

			// int choice = getValidChoice();

			System.out.println("Enter User's Choice: ");

			int choice1 = sc.nextInt();

			switch (choice1) {
			case 1:

				s.addDriverDetails();
				break;

			case 2:

				s.addCabDetails();
				break;

			case 3:

				s.addCustomerDetails();
				break;

			case 4:

				s.addRideDetails();
				break;

			case 5:

				s.displayDetails();
				break;

			case 6:

				s.calculateFare();
				break;

			case 7:

				s.startRide();
				break;

			case 8:

				s.endRide();
				break;

			case 9:
				flag = false;
				break;

			default:
				System.out.println("*********Choose a  valid choice*********");
			}

		}
		System.out.println("********THANK YOU FOR USING CAB SERVICE*********");

	}

	private static int getValidChoice() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your  choice  between 1 to  7 :");
		int ch = 0;
		try {
			ch = sc.nextInt();
		} catch (Exception e) {
			System.out.println("Invalid  input must be  in Integer");
			return getValidChoice();

		}

		return ch;
	}

}
