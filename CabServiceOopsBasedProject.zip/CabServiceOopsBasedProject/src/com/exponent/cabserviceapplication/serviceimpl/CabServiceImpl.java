package com.exponent.cabserviceapplication.serviceimpl;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.exponent.cabserviceapplication.model.Cab;
import com.exponent.cabserviceapplication.model.Customer;
import com.exponent.cabserviceapplication.model.Driver;
import com.exponent.cabserviceapplication.model.Ride;
import com.exponent.cabserviceapplication.service.CabServiceInterface;
import com.exponent.cabserviceapplication.validationchecker.ValidateAccountDetails;
import com.exponent.cabserviceapplication.validationchecker.ValidationChecker;

public class CabServiceImpl implements CabServiceInterface {
	// Implements the interface

	Scanner sc = new Scanner(System.in);
	Driver driver = new Driver();
	Cab cab = new Cab();
	Customer customer = new Customer();
	Ride ride = new Ride();

	@Override
	public void addDriverDetails() {
		System.out.println("Enter driver id: ");
		driver.setDriverid(sc.nextInt());
		System.out.println("Enter driver name: ");
		driver.setDrivername(sc.next());
		System.out.println("Enter driver Mobileno: ");
		driver.setDrivermobileNo(sc.nextLong());
		System.out.println("Enter driver pancardno: ");
		driver.setPanCard(sc.next());
		System.out.println("Enter driver licenseno: ");
		driver.setLicenseno(sc.next());
		System.out.println("Enter rating for driver: ");
		driver.setRating(sc.nextDouble());
		System.out.println("Driver's details added successfully!!");
	}

	@Override
	public void addCabDetails() {
		System.out.println("Enter cabid: ");
		cab.setCabid(sc.nextInt());
		System.out.println("Enter Cab no: ");
		cab.setCabno(sc.next());
		System.out.println("Enter Cab type: (Auto/Mini/Luxury) ");
		cab.setCabtype(sc.next());
		System.out.println("Enter Cab Availability: ");
		cab.setAvailabilityOfCab(sc.nextBoolean());
		System.out.println("Enter driver's Id for this cab service:");
		int did = sc.nextInt();
		if (did == driver.getDriverid()) {
			cab.setDriver(driver);
		} else {
			System.out.println("Driver id is invalid!!");
		}
		System.out.println("Cab details added successfully!!");

	}

	@Override
	public void addCustomerDetails() {
		System.out.println("Enter customer Id:");
		customer.setCustomerid(sc.nextInt());
		System.out.println("Enter customer Name:");
		customer.setCustomername(sc.next());
		System.out.println("Enter customer Mobile No:");
		customer.setCustomermobileno(sc.nextLong());
		System.out.println("Enter customer Address:");
		customer.setCustomeraddress(sc.next());
		System.out.println("Customer details added successfully!!");

	}

	@Override
	public void addRideDetails() {

		System.out.println("Enter Ride id: ");
		ride.setRideid(sc.nextInt());
		System.out.println("Enter Ride Pickup location: ");
		ride.setPickupLocation(sc.next());
		System.out.println("Enter Ride Drop location: ");
		ride.setDropLocation(sc.next());
		System.out.println("Enter distance: ");
		ride.setDistance(sc.nextDouble());
		System.out.println("Enter customer id: ");
		int customer_id = sc.nextInt();
		if (customer_id == customer.getCustomerid()) {
			ride.setCustomer(customer);
		} else {
			System.out.println("Customer Id is In valid!!");
		}
		System.out.println("Enter cab id: ");
		int cab_id = sc.nextInt();
		if (cab.isAvailabilityOfCab()) {
			if (cab_id == cab.getCabid()) {
				ride.setCab(cab);
			} else {
				System.out.println("Cab id is invalid!!");
//				addCabDetails();
			}

		} else {
			System.out.println("Cab is already booked!!");
		}
		System.out.println("Dear Customer " + customer.getCustomername()
				+ ", your ride is booked successfully!! Enjoy the ride..");
	}

	@Override
	public void displayDetails() {
		System.out.println("Enter ride Id:");
		int ride_id = sc.nextInt();
		if (ride_id == ride.getRideid()) {
			System.out.println(ride);
		} else {
			System.out.println("Ride id is invalid!!");
		}

	}

	@Override
	public double calculateFare() {
		double fare = 0;
		System.out.print("Dear Customer Total fare for you is Rs: ");
		if (cab.getCabtype().equalsIgnoreCase("Auto")) {
			fare = ride.getDistance() * 20;
			System.out.println(fare+" for distance: "+ride.getDistance()+" km.");
		} else if (cab.getCabtype().equalsIgnoreCase("Mini")) {
			fare = ride.getDistance() * 30;
			System.out.println(fare+" for distance: "+ride.getDistance()+" km.");
		} else if (cab.getCabtype().equalsIgnoreCase("Luxury")) {
			fare = ride.getDistance() * 40;
			System.out.println(fare+" for distance: "+ride.getDistance()+" km.");
		} else {
			System.out.println("Invalid cab type");
		}
		return fare;

	}

	@Override
	public void startRide() {

		if (cab.isAvailabilityOfCab()) {
			cab.setAvailabilityOfCab(false);
			System.out.println("\nRide started with " + cab.getDriver().getDrivername() + " for customer "
					+ customer.getCustomername());

		} else {
			System.out.println("Cab is already booked!!");

		}

	}

	@Override
	public void endRide() {
		cab.setAvailabilityOfCab(true);
		double fare = calculateFare();
		System.out.println("Dear Customer "+customer.getCustomername()+" your Ride is ended.Please pay your Total Fare: Rs." + fare);
		System.out.println("Thank you for using Cab service. ");

	}
}
