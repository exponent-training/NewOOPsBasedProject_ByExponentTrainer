package com.exponent.todolistproject.controller;

import java.util.Scanner;

import com.exponent.todolistproject.service.ToDoListServiceImpl;
import com.exponent.todolistproject.service.ToDoListServiceInterface;

public class ToDoListController {

	public static void main(String[] args) {
		System.out.println("*********ToDo List Application***********");
		Scanner sc = new Scanner(System.in);

		ToDoListServiceInterface service = new ToDoListServiceImpl();

		boolean flag = true;

		while (flag) {
			System.out.println();
			System.out.println("------------------------------------------");
			System.out.println("------------------------------------------");
			System.out.println("1: Add Task                  		|");
			System.out.println("2: View Tasks                 		|");
			System.out.println("3: Mark Task as Done         		|");
			System.out.println("4: Save The Tasks in a File   		|");
			System.out.println("5: Load Tasks Details from a File   |");
			System.out.println("6: Delete Task               		|");
			System.out.println("7: EXIT                         	|");
			System.out.println("------------------------------------------");
			System.out.println("------------------------------------------");
			System.out.println();

			// int choice = getValidChoice();

			System.out.println("Enter User's Choice: ");

			int choice1 = sc.nextInt();

			switch (choice1) {
			case 1:

				service.addTasks();
				break;

			case 2:

				service.viewTasks();
				break;

			case 3:

				service.markTaskAsDone();
				break;

			case 4:

				service.saveTaskInFile();
				break;

			case 5:

				service.loadTaskFromFile();
				break;

			case 6:

				service.deleteTask();
				break;

			case 7:
				flag = false;
				break;

			default:
				System.out.println("*********Choose a  valid choice*********");
			}

		}
		System.out.println("********THANK YOU*********");

	}

}
