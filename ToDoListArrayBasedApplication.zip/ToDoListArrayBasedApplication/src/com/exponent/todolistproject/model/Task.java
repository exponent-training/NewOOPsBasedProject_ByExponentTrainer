package com.exponent.todolistproject.model;

import java.io.Serializable;
import java.util.Date;

public class Task {

	private int taskid;
	private String description;
	private String title;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	private boolean isDone;
	private Date taskDate;

	public Date getTaskDate() {
		return taskDate;
	}

	public void setTaskDate(Date taskDate) {
		this.taskDate = taskDate;
	}

	public int getTaskid() {
		return taskid;
	}

	public void setTaskid(int taskid) {
		this.taskid = taskid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isDone() {
		return isDone;
	}

	public void setDone(boolean isDone) {
		this.isDone = isDone;
	}

	@Override
	public String toString() {
		return "Task [taskid=" + taskid + ", title=" + title +", description=" + description + ", taskDate=" + taskDate
				+ (isDone ? " is in completed stage." : " is in pending stage.")+" ]";
	}

}
