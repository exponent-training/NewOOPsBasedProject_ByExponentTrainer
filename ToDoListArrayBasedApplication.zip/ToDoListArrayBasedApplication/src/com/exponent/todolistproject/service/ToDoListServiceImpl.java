package com.exponent.todolistproject.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Date;
import java.util.Scanner;

import com.exponent.todolistproject.model.Task;

public class ToDoListServiceImpl implements ToDoListServiceInterface {

	Scanner sc = new Scanner(System.in);

	public static final int max_numbers_of_tasks = 5;
	Task[] tasks = new Task[max_numbers_of_tasks];
	private static final String FILE_NAME = "tasks.txt";

	@Override
	public void addTasks() {
		System.out.println("Enter how many tasks you want to add in your list:");
		int n = sc.nextInt();
		if (n <= tasks.length) {
			for (int i = 0; i < n; i++) {
				Task task = new Task();
				System.out.println("Enter Task ID:");
				task.setTaskid(sc.nextInt());
				sc.nextLine();
				System.out.println("Enter Task Title:");
				task.setTitle(sc.nextLine());
//				sc.nextLine();
				System.out.println("Enter Task Description:");
				task.setDescription(sc.nextLine());
//				sc.nextLine();
				System.out.println("Enter Task Date:");
				task.setTaskDate(new Date());
				System.out.print("Is Task Done? (true/false): ");
				boolean isDoneIn = sc.nextBoolean();
				task.setDone(isDoneIn);
				tasks[i] = task;
				System.out.println("Task added for " + i + " th position.");

			}
		} else {
			System.out.println("Only " + tasks.length + " tasks can be added to the ToDoList per day.");
		}

	}

	@Override
	public void viewTasks() {

		System.out.println("Task Details: ");
		/*
		 * for (Task task : tasks) { if (task != null) { System.out.println(task); }}
		 */

		for (int i = 0; i < tasks.length; i++) {
			if (tasks[i] != null) {
				System.out.println((i + 1) + ". " + tasks[i]);
			}
		}

	}

	@Override
	public void markTaskAsDone() {

		System.out.println("Enter Task Id that is done by User: ");
		int taskIdIn = sc.nextInt();
		for (Task task : tasks) {
			if (task != null && task.getTaskid() == taskIdIn) {
				task.setDone(true);
				System.out.println("Task Id: " + task.getTaskid() + " is marked as done!!");
			}
		}

	}

	@Override
	public void saveTaskInFile() {
		//Serialization
		/*
		 * try (ObjectOutputStream oos = new ObjectOutputStream(new
		 * FileOutputStream(FILE_NAME))) { for (Task task : tasks) {
		 * oos.writeObject(task); } System.out.println("Tasks are saved to file."); }
		 * catch (Exception e) { System.out.println(e); }
		 */
		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("data.txt"))) {
			for (Task task : tasks) {
				if (task!=null) {
					 writer.write(task.toString());// write string to file
			            System.out.println("Tasks written successfully.");
				}
           
			}
        } catch (Exception e) {
            e.printStackTrace();
        }

	}

	@Override
	public void loadTaskFromFile() {
		/*
		 * try (ObjectInputStream ois = new ObjectInputStream(new
		 * FileInputStream(FILE_NAME))) { Task[] taskDetails = new
		 * Task[max_numbers_of_tasks];
		 * System.out.println("Task Details loading from file: ");
		 * 
		 * for (Task task : taskDetails) { task = (Task) ois.readObject(); if (task !=
		 * null) { System.out.println(task); }
		 * 
		 * }
		 * 
		 * } catch (Exception e) { System.out.println(e); }
		 */
		
		 try (BufferedReader reader = new BufferedReader(new FileReader("data.txt"))) {
	            String line;
	            while ((line = reader.readLine()) != null) { // read line by line
	                System.out.println(line);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}

	@Override
	public void deleteTask() {
		System.out.println("Enter Task Id that an User wants to delete: ");
		int taskIdIn = sc.nextInt();

		for (int i = 0; i < tasks.length; i++) {
			if (tasks[i] != null && taskIdIn == tasks[i].getTaskid()) {
				tasks[i] = null;
				System.out.println("Task deleted successfully!!");
			}
		}
	}

}
