package com.exponent.todolistproject.service;

import java.util.Scanner;

public interface ToDoListServiceInterface {
	
	public void addTasks();
	
	public void viewTasks();
	
	public void markTaskAsDone();
	
	public void saveTaskInFile();
	
	public void loadTaskFromFile();
	
	public void deleteTask();
	
}
